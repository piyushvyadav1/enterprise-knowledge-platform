from sqlalchemy.orm import Query
from sqlalchemy import func

from app.models.document import Document
from app.models.user import User


# =========================================================
# ROLE DEFINITIONS
# =========================================================

ADMIN_ROLES = {
    "admin",
    "knowledge_manager",
    "ceo",
}


MANAGEMENT_ROLES = {
    "admin",
    "knowledge_manager",
    "ceo",
    "hr",
    "tl",
}


# =========================================================
# ACCESS LEVELS
# =========================================================

PUBLIC_ACCESS_LEVELS = {
    "public",
}

COMPANY_ACCESS_LEVELS = {
    "company",
    "company-wide",
    "global",
    "all",
}

DEPARTMENT_ACCESS_LEVELS = {
    "department",
    "department-only",
}

PRIVATE_ACCESS_LEVELS = {
    "private",
}


# =========================================================
# NORMALIZATION
# =========================================================

def normalize(value: str | None) -> str:
    """
    Normalize a single value.

    Example:
        " HR " -> "hr"
        "Sales" -> "sales"
    """

    if value is None:
        return ""

    return str(value).strip().lower()


def normalize_departments(
    value: str | None,
) -> set[str]:
    """
    Convert a department string into a set.

    Examples:

        "HR"
        -> {"hr"}

        "HR,Sales"
        -> {"hr", "sales"}

        " HR , Sales , Finance "
        -> {"hr", "sales", "finance"}
    """

    if value is None:
        return set()

    return {
        normalize(item)
        for item in str(value).split(",")
        if normalize(item)
    }


# =========================================================
# DEPARTMENT MATCHING
# =========================================================

def departments_match(
    user_department: str | None,
    document_department: str | None,
) -> bool:
    """
    Check whether the user belongs to at least one
    department assigned to the document.

    Example:

        User:
            HR

        Document:
            HR,Sales

        Result:
            True
    """

    user_departments = normalize_departments(
        user_department
    )

    document_departments = normalize_departments(
        document_department
    )

    if not user_departments:
        return False

    if not document_departments:
        return False

    return bool(
        user_departments
        & document_departments
    )


# =========================================================
# DOCUMENT ACCESS CHECK
# =========================================================

def can_access_document(
    user: User,
    document: Document,
) -> bool:
    """
    Determine whether a user can access a document.

    Rules:

    ADMIN / KNOWLEDGE MANAGER / CEO
        -> everything

    PUBLIC
        -> all authenticated users

    COMPANY
        -> all authenticated users

    DEPARTMENT
        -> users belonging to at least one assigned
           department

    PRIVATE
        -> owner or uploader only

    Unknown access level
        -> denied
    """

    # -----------------------------------------------------
    # BASIC VALIDATION
    # -----------------------------------------------------

    if user is None:
        return False

    if document is None:
        return False


    # -----------------------------------------------------
    # USER INFORMATION
    # -----------------------------------------------------

    role = normalize(
        getattr(user, "role", None)
    )

    user_department = normalize(
        getattr(user, "department", None)
    )


    # -----------------------------------------------------
    # DOCUMENT INFORMATION
    # -----------------------------------------------------

    document_department = normalize(
        getattr(document, "department", None)
    )

    access_level = normalize(
        getattr(document, "access_level", None)
    )


    # -----------------------------------------------------
    # ADMIN / KNOWLEDGE MANAGER / CEO
    # -----------------------------------------------------

    if role in ADMIN_ROLES:
        return True


    # -----------------------------------------------------
    # PUBLIC DOCUMENT
    # -----------------------------------------------------

    if access_level in PUBLIC_ACCESS_LEVELS:
        return True


    # -----------------------------------------------------
    # COMPANY-WIDE DOCUMENT
    # -----------------------------------------------------

    if access_level in COMPANY_ACCESS_LEVELS:
        return True


    # -----------------------------------------------------
    # PRIVATE DOCUMENT
    # -----------------------------------------------------

    if access_level in PRIVATE_ACCESS_LEVELS:

        # Owner
        if (
            getattr(document, "owner_id", None)
            == getattr(user, "id", None)
        ):
            return True

        # Uploader
        if (
            getattr(document, "uploaded_by", None)
            == getattr(user, "id", None)
        ):
            return True

        return False


    # -----------------------------------------------------
    # DEPARTMENT DOCUMENT
    # -----------------------------------------------------

    if access_level in DEPARTMENT_ACCESS_LEVELS:

        return departments_match(
            user_department=user_department,
            document_department=document_department,
        )


    # -----------------------------------------------------
    # UNKNOWN ACCESS LEVEL
    # -----------------------------------------------------

    # Fail closed.
    return False


# =========================================================
# SQL QUERY FILTER
# =========================================================

def apply_document_access_filter(
    query: Query,
    user: User,
) -> Query:
    """
    Apply document visibility rules directly to a SQLAlchemy
    query.

    This is used when loading the Document Library.

    Important:
        Department documents can contain multiple departments.

    Example database value:

        HR,Sales

    A Sales user will see the document.
    An HR user will see the document.
    A Finance user will not.
    """

    # -----------------------------------------------------
    # BASIC VALIDATION
    # -----------------------------------------------------

    if user is None:
        return query.filter(False)


    # -----------------------------------------------------
    # USER INFORMATION
    # -----------------------------------------------------

    role = normalize(
        getattr(user, "role", None)
    )

    user_department = normalize(
        getattr(user, "department", None)
    )


    # -----------------------------------------------------
    # ADMIN / KNOWLEDGE MANAGER / CEO
    # -----------------------------------------------------

    if role in ADMIN_ROLES:
        return query


    # -----------------------------------------------------
    # NORMAL USER
    # -----------------------------------------------------

    # If the user has no department, they cannot access
    # department-restricted documents.
    #
    # They can still access public/company documents and
    # their own private documents.

    allowed_public = (
        Document.access_level.in_(
            list(
                PUBLIC_ACCESS_LEVELS
                | COMPANY_ACCESS_LEVELS
            )
        )
    )


    # -----------------------------------------------------
    # DEPARTMENT MATCHING
    # -----------------------------------------------------

    department_condition = False

    if user_department:

        # Remove spaces from the database department field.
        #
        # Example:
        #
        # "HR, Sales"
        #
        # becomes:
        #
        # "HR,Sales"

        normalized_document_departments = func.lower(
            func.replace(
                Document.department,
                " ",
                "",
            )
        )

        department_value = normalize(
            user_department
        )


        # Exact:
        #
        # HR
        #
        exact_match = (
            normalized_document_departments
            == department_value
        )


        # Beginning:
        #
        # HR,Sales

        beginning_match = (
            normalized_document_departments.ilike(
                department_value + ",%"
            )
        )


        # End:
        #
        # Sales,HR

        ending_match = (
            normalized_document_departments.ilike(
                "%," + department_value
            )
        )


        # Middle:
        #
        # Sales,HR,Finance

        middle_match = (
            normalized_document_departments.ilike(
                "%," + department_value + ",%"
            )
        )


        department_condition = (
            exact_match
            | beginning_match
            | ending_match
            | middle_match
        )


    # -----------------------------------------------------
    # PRIVATE DOCUMENTS
    # -----------------------------------------------------

    private_condition = (
        Document.access_level.in_(
            list(PRIVATE_ACCESS_LEVELS)
        )
        &
        (
            (
                Document.owner_id
                == user.id
            )
            |
            (
                Document.uploaded_by
                == user.id
            )
        )
    )


    # -----------------------------------------------------
    # FINAL QUERY
    # -----------------------------------------------------

    return query.filter(
        allowed_public
        |
        (
            Document.access_level.in_(
                list(
                    DEPARTMENT_ACCESS_LEVELS
                )
            )
            &
            department_condition
        )
        |
        private_condition
    )